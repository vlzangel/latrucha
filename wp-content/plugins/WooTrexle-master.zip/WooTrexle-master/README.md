# WooTrexle
WooTrexle is a free WooCommerce Extension for Trexle that connects WooCommerce to +100 payment gateway like Stripe, Braintree, and authorize.net. The extension is also compatible with the subscription module to enable subscription billing.
